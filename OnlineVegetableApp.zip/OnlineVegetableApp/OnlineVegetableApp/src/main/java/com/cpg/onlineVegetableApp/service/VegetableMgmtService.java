package com.cpg.onlineVegetableApp.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpg.onlineVegetableApp.dao.IVegetableMgmtRepository;

import com.cpg.onlineVegetableApp.entities.VegetableDTO;

@Service
@Transactional
public class VegetableMgmtService implements IVegetableMgmtService {
	
	@Autowired
	IVegetableMgmtRepository repository;

	@Override
	public VegetableDTO addVegetable(VegetableDTO dto) {
		// TODO Auto-generated method stub
		try {
			VegetableDTO veggie=repository.save(dto);
			return (veggie);
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	@Override
	public VegetableDTO updateVegetable(VegetableDTO dto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public VegetableDTO removeVegetable(VegetableDTO dto) {
		// TODO Auto-generated method stub
		
		try
		{
			int id=dto.getVegId();
			Optional<VegetableDTO> optionalveg=repository.findById(id);
			VegetableDTO veggie=null;
			if(optionalveg.isPresent())
			{
				veggie=optionalveg.get();
				repository.deleteById(id);
				return veggie;
			}
			else {
			return veggie;
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	@Override
	public VegetableDTO viewVegetable(VegetableDTO dto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<VegetableDTO> viewAllVegetables() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<VegetableDTO> viewVegetableList(String category) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<VegetableDTO> viewVegetableByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
