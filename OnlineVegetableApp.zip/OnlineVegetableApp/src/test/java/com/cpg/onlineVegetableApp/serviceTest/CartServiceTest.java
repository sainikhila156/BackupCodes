package com.cpg.onlineVegetableApp.serviceTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cpg.onlineVegetableApp.entities.Cart;
import com.cpg.onlineVegetableApp.exception.CartIdNotFoundException;
import com.cpg.onlineVegetableApp.service.ICartService;

@SpringBootTest
public class CartServiceTest {

	@Autowired
	ICartService iCartService;

	Cart cart = new Cart(1, 1, null);
	Cart cart1 = new Cart(2, 2, null);
	Cart cart2 = new Cart(3,55,null);
	
	/**********************************************************************************
	 * Method Name  : addCartTest
	 * @author      : Sai Nikhila
	 * Description  : To check whether the cart is getting added or not 
	 * assertNotNull: To check that an object is not null
	 **********************************************************************************/
	  @Test void addCartTest() {
	  
	  assertNotNull(cart.getCartId());
	  }
	  
	  /**********************************************************************************
		 * Method Name  : viewCartTest
		 * @author      : Sai Nikhila
		 * Description  : To check if we can view the cart using its cartid
		 * assertEquals : To assert that expected value and actual value are equal
	  **********************************************************************************/
	  @Test
	  void viewCartTest() {
	  assertEquals(1, iCartService.viewCart(cart).getCartId()); 
	  }
	  
	  /**********************************************************************************
			 * Method Name    : viewCartTest1
			 * @author        : Sai Nikhila
			 * Description    : To check if the existed id doesnot match the given id 
			 * assertNotEquals: To assert that expected value and actual value are NOT equal
		  **********************************************************************************/
	  @Test
	  void viewCartTest1() {
	  assertNotEquals(6, iCartService.viewCart(cart).getCartId()); 
	  }
	  
	  /**********************************************************************************
			 * Method Name  : removeAllItemsTest
			 * @author      : Sai Nikhila
			 * Description  : After removing all the items checking with cart id 
			 * assertEquals : To assert that expected value and actual value are equal
	  **********************************************************************************/
	  @Test
	  void removeAllItemsTest() throws CartIdNotFoundException {
	  iCartService.addCart(cart1);
	  Cart cart3 = iCartService.removeAllItems(cart1.getCartId());
	  assertEquals(2,cart3.getCartId()); 
	  }
	 
	  
	  /**********************************************************************************
		 * Method Name  : addCartTest1
		 * @author      : Sai Nikhila
		 * Description  : To check whether the cart is getting added or not 
		 * assertNotNull: To check that an object is not null
	  **********************************************************************************/
	  @Test void addCartTest1() {
	  
	  assertEquals(1,cart.getCartId());
	  }
	  
	  
	  /**********************************************************************************
		 * Method Name    : removeAllItemsTest1
		 * @author        : Sai Nikhila
		 * Description    : After removing all the items checking with cart id  
		 * assertNotEquals: To assert that expected value and actual value are NOT equal
       *********************************************************************************/	  
	  @Test 
	  void removeAllItemsTest1() throws CartIdNotFoundException {
		  iCartService.addCart(cart1);
		  Cart cart3 = iCartService.removeAllItems(cart1.getCartId());
		  assertNotEquals(3,cart3.getCartId()); 
		  }
	 
	  /**********************************************************************************
		 * Method Name  : removeAllItemsTest2
		 * @author      : Sai Nikhila
		 * Description  : To check whether if the cart is empty 
		 * assertNotNull: To check that an object is not null
	  **********************************************************************************/

	  @Test void removeAllItemsTest2() throws CartIdNotFoundException {
		iCartService.addCart(cart1); Cart cart3 =
	    iCartService.removeAllItems(cart1.getCartId()); assertNotNull(cart3); 
	    } 
}  