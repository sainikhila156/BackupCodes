package com.cpg.onlineVegetableApp.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpg.onlineVegetableApp.dao.ICartRepository;
import com.cpg.onlineVegetableApp.dao.IVegetableMgmtRepository;
import com.cpg.onlineVegetableApp.entities.Cart;
import com.cpg.onlineVegetableApp.entities.Vegetable;
import com.cpg.onlineVegetableApp.entities.VegetableDTO;
import com.cpg.onlineVegetableApp.exception.CartIdNotFoundException;
import com.cpg.onlineVegetableApp.exception.VegetableIdNotFoundException;


@Service
@Transactional
public class CartServiceImpl implements ICartService {

	@Autowired
	private ICartRepository cartRepository;
	
	@Autowired
	private IVegetableMgmtRepository vegRepository;

	/**********************************************************************************
	 * Method Name  : removeVegetable
	 * @author      : Sai Nikhila
	 * Description  : To remove the vegetable in cart by its vegid 
	 * return cart  : returns cart after removing the vegetable
	 * Created Date : 22-March-2021
	 **********************************************************************************/
	@Override
	public Cart removeVegetable(int cartId,int vegId) throws VegetableIdNotFoundException {
		
			Optional<Cart> optionalcart = cartRepository.findById(cartId);
			Cart cart2 = null;
			if (optionalcart.isPresent()) {
				cart2 = optionalcart.get();
				List<VegetableDTO> vegetableInCart = cart2.getVegetables();
//				for (VegetableDTO veg : vegetableInCart) {
//					if (veg.getVegId() == vegId) {
//						var index = cart2.getVegetables().indexOf(veg.vegId);
//						cart2.getVegetables().remove(vegId);
//					
//						}
//						//cartRepository.deleteById(vegId);} .deleteById(vegId)
//				}
				
				for(var i = 0; i <= vegetableInCart.size(); i++) {
					if (vegetableInCart.get(i).getVegId() == vegId) {
						cart2.getVegetables().remove(i);
						break;
					}
				}
				
				//cart2 = optionalcart.get();
				return cart2;
			} 
			
			else {
					throw new VegetableIdNotFoundException("vegetable with id"+vegId+"not found");
			}
		

	}

		//cartRepository.saveAndFlush(cart1.get());
	
	/********************************************************************************** 
	 * Method Name  : increaseQuantity
	 * @author      : Sai Nikhila
	 * Description  : Increases the vegetable quantity in cart
	 * return cart  : returns cart after increasing the vegetable quantity in cart
	 * Created Date : 22-March-2021
	 **********************************************************************************/

	@Override
	public Cart increaseVegQuantity(int cartid, int vegId, int quantity) throws CartIdNotFoundException {
		
			Cart cart = null;
			Optional<Cart> optionalcart = cartRepository.findById(cartid);
			if (optionalcart.isPresent()) {
				cart = optionalcart.get();
				List<VegetableDTO> vegetableInCart = cart.getVegetables();
				for (VegetableDTO veg : vegetableInCart) {
					if (veg.getVegId() == vegId) {
						veg.setQuantity(veg.getQuantity() + quantity);
					}
				}
				return cart;
				
				
			}
			else
			{
				throw new CartIdNotFoundException("Cart with id"+cartid+"not found Exception");
			}
			

	}

	/**********************************************************************************
	 * Method Name  : decreaseQuantity
	 * @author      : Sai Nikhila
	 * Description  : Decreases the vegetable quantity in cart
	 * return cart  : returns cart after decreasing the vegetable quantity in cart
	 * Created Date : 22-March-2021
	 **********************************************************************************/
	@Override
	public Cart decreseVegQuantity(int cartid, int vegId, int quantity)throws CartIdNotFoundException{
		
			Cart cart = null;
			Optional<Cart> optionalcart = cartRepository.findById(cartid);
			if (optionalcart.isPresent()) {
				cart = optionalcart.get();
				List<VegetableDTO> vegetableInCart = cart.getVegetables();
				for (VegetableDTO veg : vegetableInCart) {
					if (veg.getVegId() == vegId) {
						if(veg.getQuantity()>=2) {
						veg.setQuantity(veg.getQuantity() - quantity);
					}
					}
				}
				return cart;
			}
			else
			{
				throw new CartIdNotFoundException("Cart with id"+cartid+"not found Exception");
			}
	}

	/**********************************************************************************
	 * Method Name  : viewAllItems
	 * @author      : Sai Nikhila
	 * Description  : View all the items present in cart
	 * return List<Vegetables> : returns all the vegetables present in cart
	 * Created Date : 22-March-2021
	 **********************************************************************************/
	@Override
	public Cart viewAllItems(int cartId) throws CartIdNotFoundException {
		
			Optional<Cart> cartoptional = null;
			cartoptional = cartRepository.findById(cartId);
			if (cartoptional.isPresent()) {
				Cart cart2 = cartoptional.get();
				return cart2;
			}
			else
			{
				throw new CartIdNotFoundException("Cart with id"+cartId+"not found Exception");
			}	
	}


	/**********************************************************************************
	 * Method Name  : removeAllItems
	 * @author      : Sai Nikhila
	 * Description  : Remove all the vegetable in cart
	 * return cart  : returns cart after removing all the vegetables present
	 * Created Date : 22-March-2021
	 **********************************************************************************/
	@Override
	public Cart removeAllItems(int cart)throws CartIdNotFoundException {
		
		Optional<Cart> cartoptional = null;
		cartoptional = cartRepository.findById(cart);
		Cart cart3 = null;
		if (cartoptional.isEmpty())
			{
			throw new CartIdNotFoundException("Cart with id "+ cart+" not found ");
		
			}
		
		cart3 = cartoptional.get();
		List<VegetableDTO> vegetableInCart = cart3.getVegetables();
		
		var vegLength = vegetableInCart.size();
		
		for(var i = 0; i < vegLength; i++) {
			
				cart3.getVegetables().remove(0);
			
		}
			//cartRepository.deleteById(cart);
		    return cart3;
		
	}

	
	
	/**********************************************************************************
	 * Method Name  : addToCart
	 * @author      : Sai Nikhila
	 * Description  : To add the items to the cart by cart id and veg id 
	 * Created date : 22-March-2021
	 * return item  : add item to the cart
	 **********************************************************************************/
	@Override
	public VegetableDTO addToCart(int cartId, VegetableDTO item)throws CartIdNotFoundException {
		// TODO Auto-generated method stub
		Optional<Vegetable> optionalVeg = vegRepository.findById(item.getVegId());
		Optional<Cart> cart1=cartRepository.findById(cartId);
		if(cart1.isPresent())
		{
		if (optionalVeg.isPresent()) {
			
			cart1.get().getVegetables().add(item);
			cartRepository.saveAndFlush(cart1.get());
		}
		}
		else
		{
			throw new CartIdNotFoundException("Cart with id "+cartId+" not found Exception");
		}
		
		return item;

	}

	/**********************************************************************************
	 * Method Name  : addCart
	 * @author      : Sai Nikhila
	 * Description  : To add the cart
	 * return cart  : cart is added for the customer
	 * Created Date : 22-March-2021
	 **********************************************************************************/
	@Override
	public Cart addCart(Cart cart) {
		// TODO Auto-generated method stub
		return cartRepository.save(cart);
	}

	/**********************************************************************************
	 * Method Name  : viewCart
	 * @author      : Sai Nikhila
	 * Description  : To view the items present in cart 
	 * return cart  : shows the cart with already present items in it 
	 * Created Date : 22-March-2021
	 **********************************************************************************/
	@Override
	public Cart viewCart(Cart cart) {
		// TODO Auto-generated method stub
		Optional<Cart> optionalcart=cartRepository.findById(cart.getCartId());
		return optionalcart.get();
	}
}

