import { ICartServiceService } from './../cart/i-cart-service.service';
import { Vegetables } from './../Vegetables';
import { Component, OnInit } from '@angular/core';
import { ViewallService } from './viewall.service';
import { Cart } from '../icart';
import { ToastService } from '../toast-global/toast-service';

/**
 * @author Sai Nikhila
 */
@Component({
  selector: 'app-viewall',
  templateUrl: './viewall.component.html',
  styleUrls: ['./viewall.component.scss']
})
export class ViewallComponent implements OnInit {

  constructor(private vService: ViewallService,private cartService:ICartServiceService, private toastService: ToastService) { }

  vegArray: Vegetables[] = []
  ngOnInit(): void {
   this.viewAllVegetables()
  }

  /**
   *
   * @param cartId
   * @param cartPayload
   */
  addToCart(cartId: number, cartPayload: any) {
    this.vService.addToCart(cartId, cartPayload).subscribe(res => {
      this.toastService.show('Item Added to Cart!!', { classname: 'bg-success text-light', delay: 3000 });
    },
    err => {
      this.toastService.show('Item is already added to Cart!!', { classname: 'bg-danger text-light', delay: 3000 });
    });
  }

  viewAllVegetables() {
    this.vService.viewVegetables().subscribe(
      (
        data: Vegetables[]) => this.vegArray = data
    )

  }
}
