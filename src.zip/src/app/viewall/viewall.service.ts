import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Vegetables } from '../Vegetables';

/**
 * @author Sai Nikhila
 */
@Injectable({
  providedIn: 'root'
})
export class ViewallService {

  veg_url:string= 'assets/Data/Vegetable.json'
  constructor(private http:HttpClient) { }

/**
 *
 * @returns Observable<Vegetables[]
 */
  viewVegetables(): Observable<Vegetables[]>{
      return this.http.get<Vegetables[]>(this.veg_url)
  }

  /**
   *
   * @param cartId
   * @param cartPayload
   * @returns Observable<any>
   */
  addToCart(cartId: number, cartPayload: any): Observable<any> {
    return this.http.post(`http://localhost:8091/cart/addtocart/${cartId}`, cartPayload);
  }


}
