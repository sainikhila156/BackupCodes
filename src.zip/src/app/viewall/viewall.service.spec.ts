import { TestBed } from '@angular/core/testing';

import { ViewallService } from './viewall.service';

describe('ViewallService', () => {
  let service: ViewallService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ViewallService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
