import { Vegetables } from './../Vegetables';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { Cart } from '../icart';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ICartServiceService } from './i-cart-service.service';
import { ToastService } from '../toast-global/toast-service';
/**
 * @author Sai Nikhila
 */
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {

  cartForm!: FormGroup
  constructor(private icartService: ICartServiceService, private fb: FormBuilder, private toastService: ToastService) { }
  cart: Cart = new Cart()
  initialNumber = 1;
  ngOnInit(): void {
    this.getAllCart()

  }
  /**
   *
   * @param cartId
   * @returns
   */
   emptyTheCart(cartId: number) {
    if (this.cart.vegetables.length === 0) {
      return this.toastService.show('Cart is Already Empty!!', { classname: 'bg-danger text-light', delay: 3000 });
    }
    this.icartService.emptyCart(cartId).toPromise().then(res2 =>{
      if (res2){
        this.cart=res2;
        this.toastService.show('Cart is Emptied Now!!', { classname: 'bg-success text-light', delay: 3000 });
      }
    })
  }
  getAllCart() {
    this.icartService.viewAllItems().subscribe((data)=>{console.log(data);this.cart=data})
  }
  /**
   *
   * @param cartId
   * @param vegId
   * @param quantity
   */
  increaseItemQuantity(cartId:number,vegId:number,quantity:number){
    this.icartService.increaseQuantity(cartId,vegId,this.initialNumber).toPromise().then(rese => {
      if (rese){
        this.cart=rese;
      }
    })
  }

  /**
   *
   * @param cartId
   * @param vegId
   * @param quantity
   */
  decreaseItemQuantity(cartId:number,vegId:number,quantity:number){
    this.icartService.decreaseQuantity(cartId,vegId,this.initialNumber).toPromise().then(rese1 => {
      if (rese1){
        this.cart=rese1;
      }
    })
  }
  /**
   *
   * @param cartId
   * @param vegId
   */
  removeVegetable(cartId: number,vegId:number){
    this.icartService.removeItem(cartId,vegId).toPromise().then(res =>{
      if (res){
        this.cart=res;
        this.toastService.show('Item is removed from Cart!', { classname: 'bg-success text-light', delay: 3000 });
      }
    })
  }
}







// showStandard() {
  //   this.toastService.show('I am a standard toast');
  // }
