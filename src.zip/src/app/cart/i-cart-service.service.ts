import { Vegetables } from './../Vegetables';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Cart } from '../icart';

/**
 * @author Sai Nikhila
 *
 */

@Injectable({
  providedIn: 'root'
})


export class ICartServiceService {
  cartArray:Cart[]=[]

  /**
   *
   * @param http
   */
  constructor(private http: HttpClient) { }



    /**
     *
     * @param cartId
     * @returns  Observable<any>
     */
  emptyCart(cartId: number): Observable<any> {
    /* this.cartArray=[]
    return this.cartArray */
    return this.http.delete(`http://localhost:8091/cart/remove/${cartId}`)
  }
  /* removeAll() : Observable<any>{
    return this.http.delete("http://localhost:8091/cart/remove/1")
  } */

  /**
   *
   * @returns  Observable<any>
   */
  public viewAllItems(): Observable<any> {
    return this.http.get("http://localhost:8091/cart/all/3")
    //return this.cartArray
  }

  /**
   *
   * @param cartId
   * @param vegId
   * @returns  Observable<any>
   */
  removeItem(cartId:number,vegId:number): Observable<any> {

    return this.http.delete(`http://localhost:8091/cart/remove/${cartId}/${vegId}`)
  }

  /**
   *
   * @param cartId
   * @param vegId
   * @param quantity
   * @returns  Observable<any>
   */
  increaseQuantity(cartId:number,vegId:number,quantity:number) : Observable<any>{
    return this.http.put(`http://localhost:8091/cart/updateinc/${cartId}/${vegId}/${quantity}`,{})
  }

  /**
   *
   * @param cartId
   * @param vegId
   * @param quantity
   * @returns  Observable<any>
   */
  decreaseQuantity(cartId:number,vegId:number,quantity:number) : Observable<any>{
    return this.http.put(`http://localhost:8091/cart/updatedec/${cartId}/${vegId}/${quantity}`,{})
  }

}
