import { Injectable, TemplateRef } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ToastService {
  toasts: any[] = [];

  /**
   *
   * @param textOrTpl
   * @param options
   */
  show(textOrTpl: string | TemplateRef<any>, options: any = {}) {
    this.toasts.push({ textOrTpl, ...options });
  }

  /**
   *
   * @param toast
   */
  remove(toast: any) {
    this.toasts = this.toasts.filter(t => t !== toast);
  }
}
