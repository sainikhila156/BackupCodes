import { Vegetables } from "./Vegetables";

export class Cart{
    cartId : number=0;
    custId : number=0;
    vegetables:Vegetables[]=[]
    constructor () {}
}
