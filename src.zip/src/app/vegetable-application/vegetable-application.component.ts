import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vegetable-application',
  templateUrl: './vegetable-application.component.html',
  styleUrls: ['./vegetable-application.component.scss']
})
export class VegetableApplicationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
